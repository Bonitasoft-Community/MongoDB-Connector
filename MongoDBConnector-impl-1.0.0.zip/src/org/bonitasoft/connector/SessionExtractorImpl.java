/**
 * 
 */
package org.bonitasoft.connector;

import java.util.List;

import org.bonitasoft.engine.connector.ConnectorException;
import org.bonitasoft.restresult.RESTResultKeyValueMap;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class SessionExtractorImpl extends AbstractSessionExtractorImpl {
	final static private String SET_COOKIE_KEY_STR = "Set-Cookie";
	final static private String JSESSIONID_KEY_STR = "JSESSIONID";
	final static private String COOKIE_PARAM_SEPARATOR_STR = ";";
	final static private String COOKIE_PARAM_PARTS_SEPARATOR_STR = "=";
	
	@Override
	protected void executeBusinessLogic() throws ConnectorException {
		setSessionResult("");
		try {
			List<RESTResultKeyValueMap> header = getLoginResult().getHeader();
			for(RESTResultKeyValueMap restResultKeyValueMap : header) {
				if(restResultKeyValueMap.getKey().equals(SET_COOKIE_KEY_STR)) {
					List<String> cookies = restResultKeyValueMap.getValue();
					for(String cookie : cookies) {
						if(cookie.contains(JSESSIONID_KEY_STR)) {
							String[] cookieParams = cookie.split(COOKIE_PARAM_SEPARATOR_STR);
							for(String cookieParam : cookieParams) {
								String[] cookieParamParts = cookieParam.split(COOKIE_PARAM_PARTS_SEPARATOR_STR);
								if(cookieParamParts.length == 2) {
									setSessionResult(cookieParamParts[1]);
									return;
								}
							}
						}
					}
				}
			}
		} catch(Exception e) {
		}
	 }

	@Override
	public void connect() throws ConnectorException{}

	@Override
	public void disconnect() throws ConnectorException{}
}
