/**
 * 
 */
package org.bonitasoft.connector;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.bonitasoft.connector.mongoDBConnector.AuthenticationFailure;
import org.bonitasoft.connector.mongoDBConnector.CollectionAccessFailure;
import org.bonitasoft.connector.mongoDBConnector.DatabaseAccessFailure;
import org.bonitasoft.connector.mongoDBConnector.InvalidCRUD;
import org.bonitasoft.connector.mongoDBConnector.InvalidKeyValueRow;
import org.bonitasoft.engine.connector.ConnectorException;
import org.bonitasoft.engine.connector.ConnectorValidationException;
import org.bonitasoft.mongodbresult.MongoDBResult;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class MongoDBConnectorImpl extends AbstractMongoDBConnectorImpl {
	private static Logger LOGGER = Logger.getLogger(MongoDBConnectorImpl.class.getName());
	
	@Override
    public void validateInputParameters() throws ConnectorValidationException {
		super.validateInputParameters();
		
		LOGGER.info("super validateInputParameters done.");
		
		final List<String> messages = new ArrayList<String>(0);
        if (getIpAddress() == null || getIpAddress().isEmpty()) {
            messages.add(IPADDRESS_INPUT_PARAMETER);
        }
        
        if (getPort() == null) {
            messages.add(PORT_INPUT_PARAMETER);
        }
        
        if(getMongoGeneration() == null) {
            messages.add(MONGOGENERATION_INPUT_PARAMETER);
        }
        
        if(getDbName() == null || getDbName().isEmpty()) {
            messages.add(DBNAME_INPUT_PARAMETER);
        }
        
        if(getDoAuth() == null) {
            messages.add(DOAUTH_INPUT_PARAMETER);
        }
        
        if(getDoAuth()) {
	        if(getUsername() == null) {
	            messages.add(USERNAME_INPUT_PARAMETER);
	        }
	        
	        if(getPassword() == null) {
	            messages.add(PASSWORD_INPUT_PARAMETER);
	        }
        }
        
        if(getCrud() == null || getCrud().isEmpty()) {
        	messages.add(CRUD_INPUT_PARAMETER);
        }
        
        List data = getData();
        if(data != null) {
	        for(Object dataElement : data) {
	        	if(dataElement instanceof List) {
	        		List dataRow = (List)dataElement;
	                if(dataRow.size() != 2) {
	                	messages.add(DATA_INPUT_PARAMETER + " - columns - " + dataRow.size());
	                } else if(dataRow.get(0) == null || dataRow.get(0).toString().isEmpty() || dataRow.get(1) == null) {
	                	messages.add(DATA_INPUT_PARAMETER + " - value");
	                }
	        	} else {
                	messages.add(DATA_INPUT_PARAMETER + " - type");
	        	}
	        }
        }
        
        List search = getSearch();
        if(search != null) {
	        for(Object searchElement : search) {
	        	if(searchElement instanceof List) {
	        		List searchRow = (List)searchElement;
	                if(searchRow.size() != 2) {
	                	messages.add(SEARCH_INPUT_PARAMETER + " - columns - " + searchRow.size());
	                } else if(searchRow.get(0) == null || searchRow.get(0).toString().isEmpty() || searchRow.get(1) == null) {
	                	messages.add(SEARCH_INPUT_PARAMETER + " - value");
	                }
	        	} else {
                	messages.add(SEARCH_INPUT_PARAMETER + " - type");
	        	}
	        }
        }
        
        if(getLimit() == null) {
        	messages.add(LIMIT_INPUT_PARAMETER);
        }
        
        if (!messages.isEmpty()) {
    		LOGGER.severe("validateInputParameters error: " + messages.toString());
            throw new ConnectorValidationException(this, messages);
        }
	}
	
	@Override
	protected void executeBusinessLogic() throws ConnectorException {
		setResult(null);
		try {
			Map<String, Object> result = MongoDBConnectorExt.mongoWork(getMongoGeneration(), getIpAddress(), getPort(), getDbName(), getDoAuth(), getUsername(), getPassword(), getCollection(), getCrud(), getData(), getSearch(), getLimit());
			if(result != null) {
				MongoDBResult finalResult = new MongoDBResult();
				finalResult.setStatus(-1);
				finalResult.setDocumentsList(null);
				finalResult.setError(null);
				if(result.containsKey(MongoDBConnectorExt.STATUS_STR)) {
					finalResult.setStatus(Integer.parseInt(result.get(MongoDBConnectorExt.STATUS_STR).toString()));
				}
				if(result.containsKey(MongoDBConnectorExt.RESULT_STR)) {
					finalResult.setDocumentsList((List<String>)result.get(MongoDBConnectorExt.RESULT_STR));
				}
				if(result.containsKey(MongoDBConnectorExt.ERROR_STR)) {
					finalResult.setError(result.get(MongoDBConnectorExt.ERROR_STR).toString());
				}
				setResult(finalResult);
			}
		} catch (UnknownHostException e) {
			reportException("executeBusinessLogic", e.getClass().getName());
		} catch (AuthenticationFailure e) {
			reportException("executeBusinessLogic", e.getClass().getName());
		} catch (DatabaseAccessFailure e) {
			reportException("executeBusinessLogic", e.getClass().getName());
		} catch (CollectionAccessFailure e) {
			reportException("executeBusinessLogic", e.getClass().getName());
		} catch (InvalidCRUD e) {
			reportException("executeBusinessLogic", e.getClass().getName());
		} catch (InvalidKeyValueRow e) {
			reportException("executeBusinessLogic", e.getClass().getName());
		}
	}
	
	private void reportException(String location, String message) throws ConnectorException {
		LOGGER.severe(location + " error: " + message);
		throw new ConnectorException(message);
	}
}
