/**
 * 
 */
package org.bonitasoft.connector.openoffice;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

import net.sf.jooreports.templates.DocumentTemplate;
import net.sf.jooreports.templates.DocumentTemplateFactory;

import org.bonitasoft.engine.connector.ConnectorException;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class GenerateDocumentFromTemplateImpl extends
		AbstractGenerateDocumentFromTemplateImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
		//getParameters();
		//getPathTemplate();
		//getFileName();
		//getMimeType();
		
		try{
		DocumentTemplateFactory documentTemplateFactory = new DocumentTemplateFactory();
		 
		DocumentTemplate template = documentTemplateFactory.getTemplate(new File(getPathTemplate()));
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		template.createDocument(getParameters(), baos);
				
		setDocument(baos.toByteArray());
		}catch(Exception e){
			e.printStackTrace();
		}
	
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}

}
