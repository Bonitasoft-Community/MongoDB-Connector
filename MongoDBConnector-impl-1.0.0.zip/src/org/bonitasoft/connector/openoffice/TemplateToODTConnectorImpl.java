/**
 * 
 */
package org.bonitasoft.connector.openoffice;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

import net.sf.jooreports.templates.DocumentTemplate;
import net.sf.jooreports.templates.DocumentTemplateFactory;

import org.bonitasoft.engine.connector.ConnectorException;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class TemplateToODTConnectorImpl extends
		AbstractTemplateToODTConnectorImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
		getInputText();
		//getPdfFileName();
		//getPdfTemplate();
		//getFileOrContent();
		try{
		DocumentTemplateFactory documentTemplateFactory = new DocumentTemplateFactory();
		 
		DocumentTemplate template = documentTemplateFactory.getTemplate(new File("C:/alba/template1.odt"));
		
		Map<String,Object> data = new HashMap<String,Object>();
		
		Map<String,Object> d = new HashMap<String,Object>();
		d.put("name","Pablo");
		d.put("surname","Alonso");
		data.put("miClase", d);
		//data.put("fecha", new Date(System.currentTimeMillis()));
		
		template.createDocument(data, new FileOutputStream("C:/alba/output1.odt"));
		}catch(Exception e){
			e.printStackTrace();
		}

		//TODO execute your business logic here 
	
		//WARNING : Set the output of the connector execution. If outputs are not set, connector fails
		//setSuccess(success);
		//setOutputFilePath(outputFilePath);
		//setOutputContent(outputContent);
	
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}

}
