package org.bonitasoft.connector.openoffice;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractTemplateToODTConnectorImpl extends
		AbstractConnector {

	protected final static String INPUTTEXT_INPUT_PARAMETER = "inputText";
	protected final static String PDFFILENAME_INPUT_PARAMETER = "pdfFileName";
	protected final static String PDFTEMPLATE_INPUT_PARAMETER = "pdfTemplate";
	protected final static String FILEORCONTENT_INPUT_PARAMETER = "fileOrContent";
	protected final String SUCCESS_OUTPUT_PARAMETER = "success";
	protected final String OUTPUTFILEPATH_OUTPUT_PARAMETER = "outputFilePath";
	protected final String OUTPUTCONTENT_OUTPUT_PARAMETER = "outputContent";

	protected final java.util.List getInputText() {
		return (java.util.List) getInputParameter(INPUTTEXT_INPUT_PARAMETER);
	}

	protected final java.lang.String getPdfFileName() {
		return (java.lang.String) getInputParameter(PDFFILENAME_INPUT_PARAMETER);
	}

	protected final java.lang.String getPdfTemplate() {
		return (java.lang.String) getInputParameter(PDFTEMPLATE_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getFileOrContent() {
		return (java.lang.Boolean) getInputParameter(FILEORCONTENT_INPUT_PARAMETER);
	}

	protected final void setSuccess(java.lang.Boolean success) {
		setOutputParameter(SUCCESS_OUTPUT_PARAMETER, success);
	}

	protected final void setOutputFilePath(java.lang.String outputFilePath) {
		setOutputParameter(OUTPUTFILEPATH_OUTPUT_PARAMETER, outputFilePath);
	}

	protected final void setOutputContent(java.lang.Object outputContent) {
		setOutputParameter(OUTPUTCONTENT_OUTPUT_PARAMETER, outputContent);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getInputText();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("inputText type is invalid");
		}
		try {
			getPdfFileName();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"pdfFileName type is invalid");
		}
		try {
			getPdfTemplate();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"pdfTemplate type is invalid");
		}
		try {
			getFileOrContent();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"fileOrContent type is invalid");
		}

	}

}
