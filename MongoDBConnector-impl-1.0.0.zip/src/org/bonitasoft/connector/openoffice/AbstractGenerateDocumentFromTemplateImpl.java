package org.bonitasoft.connector.openoffice;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGenerateDocumentFromTemplateImpl extends
		AbstractConnector {

	protected final static String PARAMETERS_INPUT_PARAMETER = "parameters";
	protected final static String PATHTEMPLATE_INPUT_PARAMETER = "pathTemplate";
	protected final String DOCUMENT_OUTPUT_PARAMETER = "document";

	protected final java.util.Map getParameters() {
		return (java.util.Map) getInputParameter(PARAMETERS_INPUT_PARAMETER);
	}

	protected final java.lang.String getPathTemplate() {
		return (java.lang.String) getInputParameter(PATHTEMPLATE_INPUT_PARAMETER);
	}

	protected final void setDocument(java.lang.Object document) {
		setOutputParameter(DOCUMENT_OUTPUT_PARAMETER, document);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getParameters();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("parameters type is invalid");
		}
		try {
			getPathTemplate();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"pathTemplate type is invalid");
		}

	}

}
