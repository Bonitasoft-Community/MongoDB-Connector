package org.bonitasoft.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractMongoDBConnectorImpl extends AbstractConnector {

	protected final static String IPADDRESS_INPUT_PARAMETER = "ipAddress";
	protected final static String PORT_INPUT_PARAMETER = "port";
	protected final static String MONGOGENERATION_INPUT_PARAMETER = "mongoGeneration";
	protected final static String DBNAME_INPUT_PARAMETER = "dbName";
	protected final static String DOAUTH_INPUT_PARAMETER = "doAuth";
	protected final static String USERNAME_INPUT_PARAMETER = "username";
	protected final static String PASSWORD_INPUT_PARAMETER = "password";
	protected final static String COLLECTION_INPUT_PARAMETER = "collection";
	protected final static String CRUD_INPUT_PARAMETER = "crud";
	protected final static String DATA_INPUT_PARAMETER = "data";
	protected final static String SEARCH_INPUT_PARAMETER = "search";
	protected final static String LIMIT_INPUT_PARAMETER = "limit";
	protected final String RESULT_OUTPUT_PARAMETER = "result";

	protected final java.lang.String getIpAddress() {
		return (java.lang.String) getInputParameter(IPADDRESS_INPUT_PARAMETER);
	}

	protected final java.lang.Integer getPort() {
		return (java.lang.Integer) getInputParameter(PORT_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getMongoGeneration() {
		return (java.lang.Boolean) getInputParameter(MONGOGENERATION_INPUT_PARAMETER);
	}

	protected final java.lang.String getDbName() {
		return (java.lang.String) getInputParameter(DBNAME_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getDoAuth() {
		return (java.lang.Boolean) getInputParameter(DOAUTH_INPUT_PARAMETER);
	}

	protected final java.lang.String getUsername() {
		return (java.lang.String) getInputParameter(USERNAME_INPUT_PARAMETER);
	}

	protected final java.lang.String getPassword() {
		return (java.lang.String) getInputParameter(PASSWORD_INPUT_PARAMETER);
	}

	protected final java.lang.String getCollection() {
		return (java.lang.String) getInputParameter(COLLECTION_INPUT_PARAMETER);
	}

	protected final java.lang.String getCrud() {
		return (java.lang.String) getInputParameter(CRUD_INPUT_PARAMETER);
	}

	protected final java.util.List getData() {
		return (java.util.List) getInputParameter(DATA_INPUT_PARAMETER);
	}

	protected final java.util.List getSearch() {
		return (java.util.List) getInputParameter(SEARCH_INPUT_PARAMETER);
	}

	protected final java.lang.Integer getLimit() {
		return (java.lang.Integer) getInputParameter(LIMIT_INPUT_PARAMETER);
	}

	protected final void setResult(
			org.bonitasoft.mongodbresult.MongoDBResult result) {
		setOutputParameter(RESULT_OUTPUT_PARAMETER, result);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getIpAddress();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("ipAddress type is invalid");
		}
		try {
			getPort();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("port type is invalid");
		}
		try {
			getMongoGeneration();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"mongoGeneration type is invalid");
		}
		try {
			getDbName();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("dbName type is invalid");
		}
		try {
			getDoAuth();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("doAuth type is invalid");
		}
		try {
			getUsername();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("username type is invalid");
		}
		try {
			getPassword();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("password type is invalid");
		}
		try {
			getCollection();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("collection type is invalid");
		}
		try {
			getCrud();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("crud type is invalid");
		}
		try {
			getData();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("data type is invalid");
		}
		try {
			getSearch();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("search type is invalid");
		}
		try {
			getLimit();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("limit type is invalid");
		}

	}

}
