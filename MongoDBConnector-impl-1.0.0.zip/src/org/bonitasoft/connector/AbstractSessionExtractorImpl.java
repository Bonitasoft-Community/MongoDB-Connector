package org.bonitasoft.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractSessionExtractorImpl extends AbstractConnector {

	protected final static String LOGINRESULT_INPUT_PARAMETER = "loginResult";
	protected final String SESSIONRESULT_OUTPUT_PARAMETER = "sessionResult";

	protected final org.bonitasoft.restresult.RESTResult getLoginResult() {
		return (org.bonitasoft.restresult.RESTResult) getInputParameter(LOGINRESULT_INPUT_PARAMETER);
	}

	protected final void setSessionResult(java.lang.String sessionResult) {
		setOutputParameter(SESSIONRESULT_OUTPUT_PARAMETER, sessionResult);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getLoginResult();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"loginResult type is invalid");
		}

	}

}
